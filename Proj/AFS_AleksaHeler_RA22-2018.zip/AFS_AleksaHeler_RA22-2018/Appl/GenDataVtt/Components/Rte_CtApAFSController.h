/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  Rte_CtApAFSController.h
 *        Config:  MyECU.dpa
 *   ECU-Project:  MyECU
 *
 *     Generator:  MICROSAR RTE Generator Version 4.9.0
 *                 RTE Core Version 1.9.0
 *       License:  Unlimited license CBD0000000 for N/A
 *
 *   Description:  Application header file for SW-C <CtApAFSController>
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_CTAPAFSCONTROLLER_H
# define _RTE_CTAPAFSCONTROLLER_H

# ifndef RTE_CORE
#  ifdef RTE_APPLICATION_HEADER_FILE
#   error Multiple application header files included.
#  endif
#  define RTE_APPLICATION_HEADER_FILE
#  ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#   define RTE_PTR2ARRAYBASETYPE_PASSING
#  endif
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CtApAFSController_Type.h"
# include "Rte_DataHandleType.h"

# ifndef RTE_CORE

/**********************************************************************************************************************
 * extern declaration of RTE buffers for optimized macro implementation
 *********************************************************************************************************************/
#  define RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

extern VAR(IdtAmbientLight, RTE_VAR_NOINIT) Rte_CpSaAmbientLight_PpAmbientLightAmountOut_DeAmbientLightAmount; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(IdtSpeedometerSpeed, RTE_VAR_NOINIT) Rte_CpSaSpeedometer_PpSpeedometerSpeedOut_DeSpeedometerSpeed; /* PRQA S 0850 */ /* MD_MSR_19.8 */
extern VAR(IdtSteeringWheelPosition, RTE_VAR_NOINIT) Rte_CpSaSteeringWheel_PpSteeringWheelPositionOut_DeSteeringWheelPosition; /* PRQA S 0850 */ /* MD_MSR_19.8 */

#  define RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

# endif /* !defined(RTE_CORE) */


# ifndef RTE_CORE
/**********************************************************************************************************************
 * Init Values for unqueued S/R communication (primitive types only)
 *********************************************************************************************************************/

#  define Rte_InitValue_PpAmbientLightAmount_DeAmbientLightAmount (0U)
#  define Rte_InitValue_PpFrontlightLeftAngle_DeFrontlightAngle (0)
#  define Rte_InitValue_PpFrontlightLeftMode_DeFrontlightMode (1U)
#  define Rte_InitValue_PpFrontlightRightAngle_DeFrontlightAngle (0)
#  define Rte_InitValue_PpFrontlightRightMode_DeFrontlightMode (1U)
#  define Rte_InitValue_PpSpeedometerSpeed_DeSpeedometerSpeed (0U)
#  define Rte_InitValue_PpSteeringWheelPosition_DeSteeringWheelPosition (0)
# endif


# define RTE_START_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * API prototypes
 *********************************************************************************************************************/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CtApAFSController_PpFrontlightLeftAngle_DeFrontlightAngle(IdtFrontlightAngle data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CtApAFSController_PpFrontlightLeftMode_DeFrontlightMode(IdtFrontlightMode data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CtApAFSController_PpFrontlightRightAngle_DeFrontlightAngle(IdtFrontlightAngle data); /* PRQA S 0850 */ /* MD_MSR_19.8 */
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_CtApAFSController_PpFrontlightRightMode_DeFrontlightMode(IdtFrontlightMode data); /* PRQA S 0850 */ /* MD_MSR_19.8 */

# define RTE_STOP_SEC_CODE
# include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


# ifndef RTE_CORE

/**********************************************************************************************************************
 * Rte_Read_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
#  define Rte_Read_PpAmbientLightAmount_DeAmbientLightAmount Rte_Read_CtApAFSController_PpAmbientLightAmount_DeAmbientLightAmount
#  define Rte_Read_CtApAFSController_PpAmbientLightAmount_DeAmbientLightAmount(data) (*(data) = Rte_CpSaAmbientLight_PpAmbientLightAmountOut_DeAmbientLightAmount, ((Std_ReturnType)RTE_E_OK)) /* PRQA S 3453 */ /* MD_MSR_19.7 */
#  define Rte_Read_PpSpeedometerSpeed_DeSpeedometerSpeed Rte_Read_CtApAFSController_PpSpeedometerSpeed_DeSpeedometerSpeed
#  define Rte_Read_CtApAFSController_PpSpeedometerSpeed_DeSpeedometerSpeed(data) (*(data) = Rte_CpSaSpeedometer_PpSpeedometerSpeedOut_DeSpeedometerSpeed, ((Std_ReturnType)RTE_E_OK)) /* PRQA S 3453 */ /* MD_MSR_19.7 */
#  define Rte_Read_PpSteeringWheelPosition_DeSteeringWheelPosition Rte_Read_CtApAFSController_PpSteeringWheelPosition_DeSteeringWheelPosition
#  define Rte_Read_CtApAFSController_PpSteeringWheelPosition_DeSteeringWheelPosition(data) (*(data) = Rte_CpSaSteeringWheel_PpSteeringWheelPositionOut_DeSteeringWheelPosition, ((Std_ReturnType)RTE_E_OK)) /* PRQA S 3453 */ /* MD_MSR_19.7 */


/**********************************************************************************************************************
 * Rte_Write_<p>_<d> (explicit S/R communication with isQueued = false)
 *********************************************************************************************************************/
#  define Rte_Write_PpFrontlightLeftAngle_DeFrontlightAngle Rte_Write_CtApAFSController_PpFrontlightLeftAngle_DeFrontlightAngle
#  define Rte_Write_PpFrontlightLeftMode_DeFrontlightMode Rte_Write_CtApAFSController_PpFrontlightLeftMode_DeFrontlightMode
#  define Rte_Write_PpFrontlightRightAngle_DeFrontlightAngle Rte_Write_CtApAFSController_PpFrontlightRightAngle_DeFrontlightAngle
#  define Rte_Write_PpFrontlightRightMode_DeFrontlightMode Rte_Write_CtApAFSController_PpFrontlightRightMode_DeFrontlightMode


/**********************************************************************************************************************
 * Rte_Call_<p>_<o> (unmapped) for synchronous C/S communication
 *********************************************************************************************************************/
#  define RTE_START_SEC_CTCDDIOHWAB_APPL_CODE
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */
FUNC(void, RTE_CTCDDIOHWAB_APPL_CODE) RCtCddIoHwAb_PpAFSSwitch_ReadChannel(P2VAR(IdtDioValueType, AUTOMATIC, RTE_CTCDDIOHWAB_APPL_VAR) value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define RTE_STOP_SEC_CTCDDIOHWAB_APPL_CODE
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

#  define Rte_Call_PpAFSSwitchIoHwAb_ReadChannel(arg1) (RCtCddIoHwAb_PpAFSSwitch_ReadChannel(arg1), ((Std_ReturnType)RTE_E_OK)) /* PRQA S 3453 */ /* MD_MSR_19.7 */
#  define RTE_START_SEC_CTCDDIOHWAB_APPL_CODE
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */
FUNC(void, RTE_CTCDDIOHWAB_APPL_CODE) RCtCddIoHwAb_PpHighBeamSwitch_ReadChannel(P2VAR(IdtDioValueType, AUTOMATIC, RTE_CTCDDIOHWAB_APPL_VAR) value); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define RTE_STOP_SEC_CTCDDIOHWAB_APPL_CODE
#  include "MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

#  define Rte_Call_PpHighBeamSwitchIoHwAb_ReadChannel(arg1) (RCtCddIoHwAb_PpHighBeamSwitch_ReadChannel(arg1), ((Std_ReturnType)RTE_E_OK)) /* PRQA S 3453 */ /* MD_MSR_19.7 */


# endif /* !defined(RTE_CORE) */


# define CtApAFSController_START_SEC_CODE
# include "CtApAFSController_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 * Runnable entities
 *********************************************************************************************************************/

# ifndef RTE_CORE
#  define RTE_RUNNABLE_RCtAFSController RCtAFSController
# endif

FUNC(void, CtApAFSController_CODE) RCtAFSController(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8, MD_Rte_3451 */

# define CtApAFSController_STOP_SEC_CODE
# include "CtApAFSController_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* _RTE_CTAPAFSCONTROLLER_H */

/**********************************************************************************************************************
 MISRA 2004 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_3451:  MISRA rule: 8.8
     Reason:     Schedulable entities are declared by the RTE and also by the BSW modules.
     Risk:       No functional risk.
     Prevention: Not required.

*/
