/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  CtApAFSController.c
 *        Config:  D:/Aleksa_Heler_RA22_2018/_MyProject/MyECU.dpa
 *     SW-C Type:  CtApAFSController
 *  Generated at:  Sat Mar 19 17:02:04 2022
 *
 *     Generator:  MICROSAR RTE Generator Version 4.9.0
 *                 RTE Core Version 1.9.0
 *       License:  Unlimited license CBD0000000 for N/A
 *
 *   Description:  C-Code implementation template for SW-C <CtApAFSController>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_Rte_0777, MD_Rte_0779 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *
 * AUTOSAR Modelling Object Descriptions
 *
 **********************************************************************************************************************
 *
 * Data Types:
 * ===========
 * IdtAmbientLight
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IdtDioValueType
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IdtFrontlightAngle
 *   sint8 represents integers with a minimum value of -128 and a maximum value of 127.
 *      The order-relation on sint8 is: x < y if y - x is positive.
 *      sint8 has a lexical representation consisting of an optional sign followed 
 *      by a finite-length sequence of decimal digits (#x30-#x39). If the sign is 
 *      omitted, "+" is assumed. 
 *      
 *      For example: -1, 0, 12678, +10000.
 *
 * IdtFrontlightMode
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IdtSpeedometerSpeed
 *   uint8 represents integers with a minimum value of 0 and a maximum value of 255.
 *      The order-relation on uint8 is: x < y if y - x is positive.
 *      uint8 has a lexical representation consisting of a finite-length sequence 
 *      of decimal digits (#x30-#x39).
 *      
 *      For example: 1, 0, 126, +10.
 *
 * IdtSteeringWheelPosition
 *   sint8 represents integers with a minimum value of -128 and a maximum value of 127.
 *      The order-relation on sint8 is: x < y if y - x is positive.
 *      sint8 has a lexical representation consisting of an optional sign followed 
 *      by a finite-length sequence of decimal digits (#x30-#x39). If the sign is 
 *      omitted, "+" is assumed. 
 *      
 *      For example: -1, 0, 12678, +10000.
 *
 *********************************************************************************************************************/

#include "Rte_CtApAFSController.h"


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* When turning left, left headlight is leading and right is trailing, with different angle scalings for each */
#define LEADING_HEADLIGHT_SCALING (30.0 / 200.0)
#define TRAILING_HEADLIGHT_SCALING (1.0 / 10.0)

#define FRONTLIGHT_CITYMODE_L (IdtFrontlightMode)50
#define FRONTLIGHT_CITYMODE_R (IdtFrontlightMode)50
#define FRONTLIGHT_COUNTRYMODE_L (IdtFrontlightMode)70
#define FRONTLIGHT_COUNTRYMODE_R (IdtFrontlightMode)120
#define FRONTLIGHT_MOTORWAYMODE_L (IdtFrontlightMode)140
#define FRONTLIGHT_MOTORWAYMODE_R (IdtFrontlightMode)200
#define FRONTLIGHT_HIGHBEAMMODE_L (IdtFrontlightMode)255
#define FRONTLIGHT_HIGHBEAMMODE_R (IdtFrontlightMode)255

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * IdtAmbientLight: Integer in interval [0...255]
 * IdtDioValueType: Integer in interval [0...255]
 * IdtFrontlightAngle: Integer in interval [-128...127]
 * IdtFrontlightMode: Integer in interval [0...255]
 * IdtSpeedometerSpeed: Integer in interval [0...255]
 * IdtSteeringWheelPosition: Integer in interval [-128...127]
 * sint8: Integer in interval [-128...127] (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 *********************************************************************************************************************/


#define CtApAFSController_START_SEC_CODE
#include "CtApAFSController_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: RCtAFSController
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on DataReceivedEvent for DataElementPrototype <DeAmbientLightAmount> of PortPrototype <PpAmbientLightAmount>
 *   - triggered on DataReceivedEvent for DataElementPrototype <DeSpeedometerSpeed> of PortPrototype <PpSpeedometerSpeed>
 *   - triggered on DataReceivedEvent for DataElementPrototype <DeSteeringWheelPosition> of PortPrototype <PpSteeringWheelPosition>
 *
 **********************************************************************************************************************
 *
 * Input Interfaces:
 * =================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Read_PpAmbientLightAmount_DeAmbientLightAmount(IdtAmbientLight *data)
 *   Std_ReturnType Rte_Read_PpSpeedometerSpeed_DeSpeedometerSpeed(IdtSpeedometerSpeed *data)
 *   Std_ReturnType Rte_Read_PpSteeringWheelPosition_DeSteeringWheelPosition(IdtSteeringWheelPosition *data)
 *
 * Output Interfaces:
 * ==================
 *   Explicit S/R API:
 *   -----------------
 *   Std_ReturnType Rte_Write_PpFrontlightLeftAngle_DeFrontlightAngle(IdtFrontlightAngle data)
 *   Std_ReturnType Rte_Write_PpFrontlightLeftMode_DeFrontlightMode(IdtFrontlightMode data)
 *   Std_ReturnType Rte_Write_PpFrontlightRightAngle_DeFrontlightAngle(IdtFrontlightAngle data)
 *   Std_ReturnType Rte_Write_PpFrontlightRightMode_DeFrontlightMode(IdtFrontlightMode data)
 *
 * Client/Server Interfaces:
 * =========================
 *   Server Invocation:
 *   ------------------
 *   Std_ReturnType Rte_Call_PpAFSSwitchIoHwAb_ReadChannel(IdtDioValueType *value)
 *     Synchronous Server Invocation. Timeout: None
 *   Std_ReturnType Rte_Call_PpHighBeamSwitchIoHwAb_ReadChannel(IdtDioValueType *value)
 *     Synchronous Server Invocation. Timeout: None
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: RCtAFSController_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CtApAFSController_CODE) RCtAFSController(void) /* PRQA S 0850 */ /* MD_MSR_19.8 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: RCtAFSController
 *********************************************************************************************************************/

	/* Local vars */
	IdtDioValueType localAFSState;						// AFS on/off
	IdtDioValueType localHighBeamState;					// High beam on/off
	IdtSteeringWheelPosition steeringWheelPosition;		// Steering wheel angle
	IdtSpeedometerSpeed speedometerSpeed;
	IdtAmbientLight ambientLightAmount;

	IdtFrontlightAngle localFrontlightLeftAngle;		// Light angle
	IdtFrontlightAngle localFrontlightRightAngle;
	IdtFrontlightMode localFrontlightLeftMode;			// Light mode (2bit)
	IdtFrontlightMode localFrontlightRightMode;


	/* Get hw switches and steering wheel */
	Rte_Call_PpAFSSwitchIoHwAb_ReadChannel(&localAFSState);
	Rte_Call_PpHighBeamSwitchIoHwAb_ReadChannel(&localHighBeamState);
	Rte_Read_CtApAFSController_PpSteeringWheelPosition_DeSteeringWheelPosition(&steeringWheelPosition);
	Rte_Read_CtApAFSController_PpSpeedometerSpeed_DeSpeedometerSpeed(&speedometerSpeed);
	Rte_Read_CtApAFSController_PpAmbientLightAmount_DeAmbientLightAmount(&ambientLightAmount);
	
	/* Adaptive frontlight system - OFF */
	if (localAFSState == FALSE){
		/* Write init value angle and high beam mode to frontlights */
		localFrontlightLeftAngle = (IdtFrontlightAngle)0;
		localFrontlightRightAngle = (IdtFrontlightAngle)0;

		if (localHighBeamState == TRUE){
			localFrontlightLeftMode = FRONTLIGHT_HIGHBEAMMODE_L;
			localFrontlightRightMode = FRONTLIGHT_HIGHBEAMMODE_R;
		}
		else{
			localFrontlightLeftMode = FRONTLIGHT_COUNTRYMODE_L;
			localFrontlightRightMode = FRONTLIGHT_COUNTRYMODE_R;
		}
	}
	/* Adaptive frontlight system - ON */
	else{

		if (steeringWheelPosition < 0){ /* Steering negative - LEFT */
			localFrontlightLeftAngle = (IdtFrontlightAngle)steeringWheelPosition * LEADING_HEADLIGHT_SCALING;
			localFrontlightRightAngle = (IdtFrontlightAngle)steeringWheelPosition * TRAILING_HEADLIGHT_SCALING;
		}
		else{ /* Steering positive - RIGHT */
			localFrontlightLeftAngle = (IdtFrontlightAngle)steeringWheelPosition * TRAILING_HEADLIGHT_SCALING;
			localFrontlightRightAngle = (IdtFrontlightAngle)steeringWheelPosition * LEADING_HEADLIGHT_SCALING;
		}

		/* Set mode based on high beam mode, speed and ambient light */
		if (localHighBeamState == TRUE){
			localFrontlightLeftMode = FRONTLIGHT_HIGHBEAMMODE_L;
			localFrontlightRightMode = FRONTLIGHT_HIGHBEAMMODE_R;
		}
		else{
			/* Ambient light 0-5 */
			if (ambientLightAmount < 5){
				/* Speedometer speed 0-50 */
				if (speedometerSpeed < 50){
					localFrontlightLeftMode = FRONTLIGHT_CITYMODE_L;
					localFrontlightRightMode = FRONTLIGHT_CITYMODE_R;
				}
				/* Speedometer speed 50-120 */
				else if (speedometerSpeed < 120){
					localFrontlightLeftMode = FRONTLIGHT_COUNTRYMODE_L;
					localFrontlightRightMode = FRONTLIGHT_COUNTRYMODE_R;
				}
				/* Speedometer speed 120-250 */
				else{
					localFrontlightLeftMode = FRONTLIGHT_MOTORWAYMODE_L;
					localFrontlightRightMode = FRONTLIGHT_MOTORWAYMODE_R;
				}
			}
			/* Ambient light 5-10 */
			else{
				localFrontlightLeftMode = FRONTLIGHT_CITYMODE_L;
				localFrontlightRightMode = FRONTLIGHT_CITYMODE_R;
			}
		}
	}

	/* Write angle and mode to frontlights */
	Rte_Write_PpFrontlightLeftAngle_DeFrontlightAngle(localFrontlightLeftAngle);
	Rte_Write_PpFrontlightRightAngle_DeFrontlightAngle(localFrontlightRightAngle);
	Rte_Write_PpFrontlightLeftMode_DeFrontlightMode(localFrontlightLeftMode);
	Rte_Write_PpFrontlightRightMode_DeFrontlightMode(localFrontlightRightMode);


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CtApAFSController_STOP_SEC_CODE
#include "CtApAFSController_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_19.1 */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 MISRA 2004 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_0777:  MISRA rule: 5.1
     Reason:     The defined RTE naming convention may result in identifiers with more than 31 characters. The compliance to this rule is under user's control.
                 This is covered in the MISRA C compliance section of the Rte specification.
     Risk:       Ambiguous identifiers can lead to compiler errors / warnings.
     Prevention: Verified during compile time. If the compiler reports an error or warning, the user has to rename the objects to be unique within the significant characters.

   MD_Rte_0779:  MISRA rule: 5.1
     Reason:     The defined RTE naming convention may result in identifiers with more than 31 characters. The compliance to this rule is under user's control.
                 This is covered in the MISRA C compliance section of the Rte specification.
     Risk:       Ambiguous identifiers can lead to compiler errors / warnings.
     Prevention: Verified during compile time. If the compiler reports an error or warning, the user has to rename the objects to be unique within the significant characters.

*/
