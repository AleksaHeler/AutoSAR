/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  Rte_DataHandleType.h
 *        Config:  D:/Aleksa_Heler_RA22_2018/_MyProject/MyECU.dpa
 *     SW-C Type:  CtSaSpeedometer
 *  Generated at:  Sat Mar 19 17:02:12 2022
 *
 *     Generator:  MICROSAR RTE Generator Version 4.9.0
 *                 RTE Core Version 1.9.0
 *       License:  Unlimited license CBD0000000 for N/A
 *
 *   Description:  Header file containing Data Handle type declarations for component data structures (ContractPhase)
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_DATA_HANDLE_TYPE_H
# define _RTE_DATA_HANDLE_TYPE_H

#endif /* _RTE_DATA_HANDLE_TYPE_H */
